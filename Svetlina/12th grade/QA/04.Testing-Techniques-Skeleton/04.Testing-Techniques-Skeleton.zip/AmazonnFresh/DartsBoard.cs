﻿namespace AmazonnFresh
{
    public class DartsBoard : Product
    {
        public DartsBoard() : base(20.00m, false) { }
    }
}
