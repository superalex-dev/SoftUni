﻿namespace AmazonnFresh
{
    public class AmazonDarts : Product
    {
        public AmazonDarts() : base(5.00m, true) { }
    }
}
