﻿using CustomerBank;

using NUnit.Framework;

namespace BoundaryValueAnalysis.Tests
{
    public class BankBoundaryValueAnalysis
    {
        [SetUp]
        public void SetUp()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_LowerBound_BelowEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_LowerBound_OnEdge()
        { 
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_LowerBound_AboveEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_UpperBound_BelowEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_UpperBound_OnEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Amount_UpperBound_AboveEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Loyalty_BelowEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Loyalty_OnEdge()
        {
        }

        [Test]
        public void Test_Bank_RequestLoan_Loyalty_OverEdge()
        {
        }
    }
}
