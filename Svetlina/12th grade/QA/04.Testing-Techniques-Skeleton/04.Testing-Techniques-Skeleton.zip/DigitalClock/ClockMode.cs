﻿namespace DigitalClock
{
    public enum ClockMode
    {
        DisplayTime,
        SetHour,
        SetMinute,
        SetDay,
        SetMonth,
        SetYear
    }
}
