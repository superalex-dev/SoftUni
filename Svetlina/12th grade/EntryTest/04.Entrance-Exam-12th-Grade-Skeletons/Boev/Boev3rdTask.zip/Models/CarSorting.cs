﻿
namespace CarRentalSystem.Models
{
    public enum CarSorting
    {
        Newest = 0,
        Price = 1,
        NotRenedFirst = 2,
    }
}
