﻿using Microsoft.AspNetCore.Identity;

namespace CarRentalSystem.Data.Entities
{
    public class ApplicationUser : IdentityUser
    {
    }
}
