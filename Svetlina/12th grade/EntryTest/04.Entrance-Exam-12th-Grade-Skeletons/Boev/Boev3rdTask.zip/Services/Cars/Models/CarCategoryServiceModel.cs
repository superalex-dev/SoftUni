﻿
namespace CarRentalSystem.Services.Cars.Models
{
    public class CarCategoryServiceModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
