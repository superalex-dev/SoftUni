﻿
namespace Shop
{
    public enum Prices
    {
        Cup = 10,
        Shirt = 20,
    }
}
