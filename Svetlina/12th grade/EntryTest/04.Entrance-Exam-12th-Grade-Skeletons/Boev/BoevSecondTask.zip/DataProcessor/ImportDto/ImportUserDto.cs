﻿
namespace MyCalendar.DataProcessor.ImportDto
{
    public class ImportUserDto
    {
        public string Name { get; set; }
        public ImportEventDto[] Events { get; set; }
    }
}
