﻿namespace Mini_Exam_Interfaces_and_Abstraction;

public interface IPerson
{
    string FirstName { get; set; }
    string LastName { get; set; }
}