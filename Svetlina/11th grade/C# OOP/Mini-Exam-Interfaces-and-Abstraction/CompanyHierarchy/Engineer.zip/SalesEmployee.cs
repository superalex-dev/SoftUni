﻿namespace CompanyHierarchy
{
    public class SalesEmployee : IEmployee
    {
        private readonly string firstName;
        private readonly string lastName;
        private readonly string department;
        private readonly decimal salary;
        private readonly decimal profits;

        public SalesEmployee(string firstName, string lastName, string department, decimal profits)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.department = department;
            this.salary = 1000;
            this.profits = profits;
        }

        public string FirstName => firstName; 
        public string LastName => lastName; 
        public string Department => department; 
        public decimal Salary => salary; 
        public decimal Profits => profits;
        public decimal GetSalary()
        {
            return Salary + (Profits * 0.1m);
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} from {Department} has {Profits} profits.";
        }
    }

}