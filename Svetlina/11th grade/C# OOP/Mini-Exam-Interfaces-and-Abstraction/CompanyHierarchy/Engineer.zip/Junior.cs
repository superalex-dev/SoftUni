﻿namespace CompanyHierarchy
{
    public class Junior : IEmployee
    {
        private readonly string firstName;
        private readonly string department;
        private readonly string lastName;
        private readonly decimal salary;

        public Junior(string firstName, string lastName, string department)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.department = department;
            this.salary = 900;
        }

        public string FirstName => firstName;
        public string LastName => lastName;
        public string Department => department;
        public decimal Salary => salary;
        public decimal GetSalary()
        {
            return Salary;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} is Junior engineer.";
        }
    }
}