﻿namespace CompanyHierarchy
{
    public class Engineer : IEmployee
    {
        public Engineer(string firstName, string lastName, string department, int yearsService)
        {
            FirstName = firstName;
            LastName = lastName;
            Department = department;
            YearsService = yearsService;
            Salary = 1300;
        }

        public string FirstName { get; }
        public string LastName { get; }
        public string Department { get; }
        public decimal Salary { get; }
        public int YearsService { get; }

        public decimal GetSalary()
        {
            return Salary + (YearsService * 90);
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} from {Department} has {YearsService} years of service.";
        }
    }
}