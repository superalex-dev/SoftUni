﻿using System;

namespace CompanyHierarchy
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IEmployee> employees = new List<IEmployee>();
            while (true)
            {
                var input = Console.ReadLine().Split();
                if (input[0] == "End")
                {
                    break;
                }

                var firstName = input[0];
                var lastName = input[1];
                var department = input[2];

                switch (department)
                {
                    case "Sales":
                        var profits = decimal.Parse(input[3]);
                        var temp = new SalesEmployee(firstName, lastName, department, profits);
                        Console.WriteLine(temp);
                        Console.WriteLine($"Receives a salary of {temp.GetSalary():f1}.");
                        break;

                    case "Engineering":
                        var yearsService = int.Parse(input[3]);
                        var temp1 = new Engineer(firstName, lastName, department, yearsService);
                        Console.WriteLine(temp1);
                        Console.WriteLine($"Receives a salary of {temp1.GetSalary():f0}.");
                        break;

                    case "Junior":
                        var temp2 = new Junior(firstName, lastName, department);
                        Console.WriteLine(temp2);
                        Console.WriteLine($"Receives a salary of {temp2.GetSalary():f0}.");
                        break;

                    default:
                        throw new ArgumentException("Invalid department");
                }
            }

            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
                Console.WriteLine($"Receives a salary of {employee.GetSalary()}.");
            }
        }
    }
}